from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name='mypythonlib',  # Replace with your desired package name
    version='0.1.0',
    author='Your Name',
    author_email='your@email.com',
    description='My Python Library for Data Manipulation',  # Replace with your library's description
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/yourusername/mypythonlib',  # Replace with your GitHub repository URL
    packages=find_packages(include=['mypythonlib']),  # Include only relevant packages
    install_requires=[
        'pandas',  # Add any dependencies your library requires
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    test_suite='tests',  # Specify the folder containing your test cases
)
